// SPDX-FileCopyrightText: 2022 UnionTech Software Technology Co., Ltd.
//
// SPDX-License-Identifier: LGPL-3.0-or-later

#define DSEARCH_NAMESPACE Dtk::Search

#define DSEARCH_USE_NAMESPACE using namespace DSEARCH_NAMESPACE;

#define DSEARCH_BEGIN_NAMESPACE \
    namespace Dtk {             \
    namespace Search {
#define DSEARCH_END_NAMESPACE \
    }                         \
    }
