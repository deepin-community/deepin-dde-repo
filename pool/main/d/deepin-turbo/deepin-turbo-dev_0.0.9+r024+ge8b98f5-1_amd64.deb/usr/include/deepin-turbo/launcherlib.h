#ifndef LAUNCHERLIB_H
#define LAUNCHERLIB_H

#define DECL_EXPORT __attribute__ ((__visibility__("default")))
#define BEGIN_NAMESPACE namespace DeepinTurbo {
#define END_NAMESPACE }

#endif
