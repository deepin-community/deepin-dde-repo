// SPDX-FileCopyrightText: 2015 - 2022 UnionTech Software Technology Co., Ltd.
//
// SPDX-License-Identifier: LGPL-3.0-or-later

#ifndef DINPUTDIALOG_P_H
#define DINPUTDIALOG_P_H

#endif // DINPUTDIALOG_P_H

