// Copyright (C) 2021 UOS Technology Co., Ltd.
// SPDX-FileCopyrightText: 2022 UnionTech Software Technology Co., Ltd.
//
// SPDX-License-Identifier: GPL-3.0-or-later

#ifndef DASEFINE_H
#define DASEFINE_H

#define DAS_NAMESPACE deepin_anything_server
#define DAS_BEGIN_NAMESPACE namespace DAS_NAMESPACE {
#define DAS_END_NAMESPACE }

#endif // DASEFINE_H
