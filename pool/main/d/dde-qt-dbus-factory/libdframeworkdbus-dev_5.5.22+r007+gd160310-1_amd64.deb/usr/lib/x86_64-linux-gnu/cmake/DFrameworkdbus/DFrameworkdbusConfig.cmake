set(DFrameworkdbus_INCLUDE_DIR /usr/include/libdframeworkdbus-2.0)
set(DFrameworkdbus_LIBRARIES dframeworkdbus)
include_directories(${DFrameworkdbus_INCLUDE_DIR})
